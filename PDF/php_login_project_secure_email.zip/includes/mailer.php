<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
function enviarEmail($email, $token){
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'SEU_EMAIL@gmail.com';
        $mail->Password = 'SUA_SENHA_APP';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('SEU_EMAIL@gmail.com', 'Sistema Login');
        $mail->addAddress($email);
        $mail->Subject = 'Redefinição de Senha';
        $link = 'http://localhost/php_login_project_secure/reset.php?token='.$token;
        $mail->Body = 'Clique para redefinir sua senha: '.$link;
        $mail->send();
    } catch (Exception $e) {
        echo 'Erro ao enviar e-mail: ', $mail->ErrorInfo;
    }
}
?>