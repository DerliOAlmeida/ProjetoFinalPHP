<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang='pt-br'>
<head>
<meta charset='UTF-8'>
<title>Cadastro</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
<script src='https://www.google.com/recaptcha/api.js' async defer></script>
<script src='assets/script.js' defer></script>
</head>
<body class='bg-light'>
<div class='container mt-5'>
<div class='card p-4 shadow'>
<h2 class='mb-3'>Cadastrar Usuário</h2>
<form action='cadastro.php' method='POST' onsubmit='return validarFormularioCadastro()'>
<input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
<div class='mb-3'><input type='text' name='nome' class='form-control' placeholder='Nome' required></div>
<div class='mb-3'><input type='email' name='email' class='form-control' placeholder='E-mail' required></div>
<div class='mb-3'><input type='password' name='senha' class='form-control' placeholder='Senha' required></div>
<div class='g-recaptcha mb-3' data-sitekey='SUA_CHAVE_SITE'></div>
<button type='submit' class='btn btn-success w-100'>Cadastrar</button>
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('CSRF token inválido');
    }
    include 'includes/db_connect.php';
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $nome, $email, $senha);
    if ($stmt->execute()) {
        echo '<p class="text-success">Usuário cadastrado com sucesso!</p>';
    } else {
        echo '<p class="text-danger">Erro ao cadastrar: ' . $stmt->error . '</p>';
    }
}
?>
</div>
</div>
<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>
</body>
</html>
