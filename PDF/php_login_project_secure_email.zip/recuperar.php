<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang='pt-br'>
<head>
<meta charset='UTF-8'>
<title>Recuperar Senha</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body class='bg-light'>
<div class='container mt-5'>
<div class='card p-4 shadow'>
<h2 class='mb-3'>Recuperar Senha</h2>
<form action='recuperar.php' method='POST'>
<input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
<div class='mb-3'><input type='email' name='email' class='form-control' placeholder='Digite seu e-mail' required></div>
<button type='submit' class='btn btn-warning w-100'>Enviar link</button>
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die('CSRF token inválido');
    }
    include 'includes/db_connect.php';
    $email = $_POST['email'];
    $token = bin2hex(random_bytes(16));
    $sql = "UPDATE usuarios SET reset_token=? WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $token, $email);
    if ($stmt->execute()) {
        // Enviar e-mail com PHPMailer
        require 'includes/mailer.php';
        enviarEmail($email, $token);
        echo '<p class="text-success">Verifique seu e-mail para redefinir a senha.</p>';
    } else {
        echo '<p class="text-danger">Erro ao processar.</p>';
    }
}
?>
</div>
</div>
<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>
</body>
</html>
