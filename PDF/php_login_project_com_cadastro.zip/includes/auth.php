<?php
<?php
session_start();

function autenticar($email, $senha) {
    global $conn;
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['usuario'] = $usuario['nome'];
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<p>Senha incorreta!</p>";
        }
    } else {
        echo "<p>E-mail não encontrado!</p>";
    }
}
?>