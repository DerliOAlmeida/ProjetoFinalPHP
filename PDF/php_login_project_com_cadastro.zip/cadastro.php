<?php
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body>
    <div class="login-container">
        <h2>Cadastrar Usuário</h2>
        <form action="cadastro.php" method="POST" onsubmit="return validarFormularioCadastro()">
            <input type="text" name="nome" placeholder="Nome" required>
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Cadastrar</button>
        </form>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            include 'includes/db_connect.php';
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

            $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $nome, $email, $senha);

            if ($stmt->execute()) {
                echo "<p>Usuário cadastrado com sucesso!</p>";
            } else {
                echo "<p>Erro ao cadastrar: " . $stmt->error . "</p>";
            }
        }
        ?>
    </div>
</body>
</html>
?>