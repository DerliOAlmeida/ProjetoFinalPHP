<?php
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="index.php" method="POST" onsubmit="return validarFormulario()">
            <input type="text" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>
        </form>
        <p><a href="cadastro.php">Cadastrar novo usuário</a></p>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            include 'includes/db_connect.php';
            include 'includes/auth.php';
            autenticar($_POST['email'], $_POST['senha']);
        }
        ?>
    </div>
</body>
</html>
?>