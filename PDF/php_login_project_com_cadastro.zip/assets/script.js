function validarFormulario() {
    const email = document.querySelector('input[name="email"]').value;
    const senha = document.querySelector('input[name="senha"]').value;

    if (email === '' || senha === '') {
        alert('Preencha todos os campos!');
        return false;
    }
    return true;
}

function validarFormularioCadastro() {
    const nome = document.querySelector('input[name="nome"]').value;
    const email = document.querySelector('input[name="email"]').value;
    const senha = document.querySelector('input[name="senha"]').value;

    if (nome === '' || email === '' || senha === '') {
        alert('Preencha todos os campos!');
        return false;
    }
    if (senha.length < 6) {
        alert('A senha deve ter pelo menos 6 caracteres!');
        return false;
    }
    return true;
}